# AdaBoost:使用AdaBoost对房价进行预测

## 如何使用AdaBoost工具

## 如何应AdaBoost对房价进行预测

## AdaBoost与决策树模型的比较

## 总结